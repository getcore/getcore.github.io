window.addEventListener("load", function(){
	var load = document.getElementById("loadSync");
	document.body.removeChild(load);
});
